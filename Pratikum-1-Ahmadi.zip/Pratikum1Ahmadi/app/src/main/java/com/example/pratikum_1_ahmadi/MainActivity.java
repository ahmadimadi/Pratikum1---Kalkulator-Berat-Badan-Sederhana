package com.example.pratikum_1_ahmadi;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    Button btnHitung;
    EditText edtBB, edtTB;
    TextView edHasil;
    float bb,bmi,tb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//inisialisasi variabel
        edHasil = (TextView)findViewById(R.id.result);
        edtBB = (EditText)findViewById(R.id.berat);
        edtTB = (EditText)findViewById(R.id.tinggi);
        btnHitung = (Button)findViewById(R.id.proses);
        //set on click listener pada button
        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtBB.getText().toString().equals("")||edtTB.getText().toString().equals(" ")) {
                        Toast.makeText(getApplicationContext(), "Mohon untuk melengkapi data", Toast.LENGTH_SHORT).show();
            }else{
                bb = Integer.parseInt(edtBB.getText().toString());
                tb = Integer.parseInt(edtTB.getText().toString());
                bmi = tb-100;
                // menampilkan hasil
                edHasil.setText(String.valueOf("Ahmadi Berat Ideal anda harusnya "+bmi+"Kg. Bukan"+bb+"Kg"));
            }
        }
    });
}
}