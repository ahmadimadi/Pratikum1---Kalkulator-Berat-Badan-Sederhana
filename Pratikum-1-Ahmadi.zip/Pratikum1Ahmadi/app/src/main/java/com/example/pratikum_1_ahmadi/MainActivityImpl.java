package com.example.pratikum_1_ahmadi;

public class MainActivityImpl extends MainActivity {
}
